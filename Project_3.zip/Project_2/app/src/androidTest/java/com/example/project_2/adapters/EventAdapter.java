package com.example.project_2.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.project_2.R;
import com.example.project_2.database.DatabaseHelper;
import com.example.project_2.model.Event;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    List<Event> eventList;
    DatabaseHelper db;

    public EventAdapter(List<Event> list, DatabaseHelper db) {
        this.eventList = list;
        this.db = db;
    }

    // ✅ REQUIRED
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    // ✅ REQUIRED
    @Override
    public int getItemCount() {
        return eventList.size();
    }

    // Bind data to row
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Event e = eventList.get(position);

        holder.name.setText(e.name);
        holder.date.setText(e.date);

        // ✅ Delete logic
        holder.delete.setOnClickListener(v -> {
            db.deleteEvent(e.id);
            eventList.remove(position);
            notifyItemRemoved(position);
        });
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, date;
        Button delete;

        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.textItemName);
            date = itemView.findViewById(R.id.textItemQuantity);
            delete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}