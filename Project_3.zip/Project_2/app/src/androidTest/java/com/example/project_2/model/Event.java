package com.example.project_2.model;
public class Event {
    public int id;
    public String name;
    public String date;

    public Event(int id, String name, String date) {
        this.id = id;
        this.name = name;
        this.date = date;
    }
}