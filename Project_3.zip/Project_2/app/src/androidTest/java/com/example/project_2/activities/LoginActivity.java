package com.example.project_2.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.project_2.R;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project_2.database.DatabaseHelper;

public class LoginActivity extends AppCompatActivity {

    EditText usernameText, passwordText;
    Button buttonLogin, buttonCreateAccount;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI elements
        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        db = new DatabaseHelper(this);

        // Login button
        buttonLogin.setOnClickListener(v -> {
            String user = usernameText.getText().toString().trim();
            String pass = passwordText.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.loginUser(user, pass)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                // Move to DataActivity
                startActivity(new Intent(this, DataActivity.class));
            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        });

        // Create account button
        buttonCreateAccount.setOnClickListener(v -> {
            String user = usernameText.getText().toString().trim();
            String pass = passwordText.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.registerUser(user, pass)) {
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show();
            }
        });
    }
}