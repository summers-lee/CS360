package com.example.project_2.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import com.example.project_2.R;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project_2.database.DatabaseHelper;

import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {

    EditText eventNameText, eventDateText;
    Button buttonAddEvent;
    RecyclerView recyclerView;

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Link UI
        eventNameText = findViewById(R.id.eventNameText);
        eventDateText = findViewById(R.id.eventDateText);
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        recyclerView = findViewById(R.id.recyclerViewData);

        db = new DatabaseHelper(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Add event button
        buttonAddEvent.setOnClickListener(v -> {
            String name = eventNameText.getText().toString().trim();
            String date = eventDateText.getText().toString().trim();

            if (!name.isEmpty() && !date.isEmpty()) {
                db.addEvent(name, date);

                // Optional: trigger SMS alert
                checkSmsPermission();
            }
        });
    }

    // ✅ Check permission
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, 1);
        } else {
            sendSMS();
        }
    }

    // ✅ Send SMS
    private void sendSMS() {
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage("1234567890", null,
                "Upcoming event added!", null, null);
    }

    // ✅ Handle permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 1) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                sendSMS();
            }
            // If denied → do nothing (app still works ✔)
        }
    }
}